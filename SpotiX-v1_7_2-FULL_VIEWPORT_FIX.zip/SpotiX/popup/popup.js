/* SpotiX — popup kontrolü (TR/EN) */
(function () {
  'use strict';

  const S = Object.assign({}, SX.DEFAULTS);
  const hasChrome =
    typeof chrome !== 'undefined' && !!(chrome.storage && chrome.storage.sync);

  const I18N = {
    tr: {
      secPresets: 'Hazır temalar', secColors: 'Renkler',
      bg: 'Arka plan', surface: 'Kart / yüzey', accent: 'Vurgu rengi', text: 'Metin',
      secScaleP: 'Ölçek',
      scaleP: 'UI ölçeği (dokunmatik ekranda)',
      scaleMode: 'Ölçek modu',
      smAuto: 'Otomatik', smOn: 'Hep açık', smOff: 'Kapalı',
      secInteractionP: 'Etkileşim',
      pwKeepAlive: 'Kilitte çalmaya devam (canlı tutma)',
      pwSpeed: 'Çalma hızı (slowed/nightcore)',
      pwQuality: 'Ses kalitesi',
      qFixedHigh: 'En yüksek (zorlanır)',
      secExtras: 'Ekstralar',
      pwAd: 'Reklam engelleyici (beta)',
            cacheTitle: 'Bakım (bu sekmenin önbelleği)', cacheUsage: 'Kullanım',
      cacheBtn: 'Önbelleği temizle', cacheSure: 'Emin misin? Önbellek sıfırlanır',
      cacheYes: 'Evet, temizle', cacheNo: 'Vazgeç',
      cacheDone: 'temizlendi 🧹', cacheFail: 'temizlenemedi',
      cacheNoTab: 'Spotify sekmesi açık olmalı',
      pwPlayerScale: 'Player boyutu (bağımsız)',
      pwCover: 'Kapak resmi (alt bar)',
      pwCoverSize: 'Kapak boyutu',
      otherP: 'Diğer',
      pwThin: 'İnce kaydırma çubuğu',
      langLabel: 'Dil',
      resetBtn: '↺ Varsayılanlara dön',
      instantNote: 'Değişiklikler açık Spotify sekmelerine anında yansır — yenileme gerekmez 🎧',
      pAMOLED: 'AMOLED', pClassic: 'Klasik', pNight: 'Gece', pNeon: 'Neon',
      pBlood: 'Kan', pForest: 'Orman', pAprel: 'Aprel'
    },
    en: {
      secPresets: 'Presets', secColors: 'Colors',
      bg: 'Background', surface: 'Card / surface', accent: 'Accent color', text: 'Text',
      secScaleP: 'Scale',
      scaleP: 'UI scale (on touch screens)',
      scaleMode: 'Scale mode',
      smAuto: 'Auto', smOn: 'Always on', smOff: 'Off',
      secInteractionP: 'Interaction',
      pwKeepAlive: 'Keep playing when locked (keep-alive)',
      pwSpeed: 'Playback speed (slowed/nightcore)',
      pwQuality: 'Audio quality',
      qFixedHigh: 'Highest (forced)',
      secExtras: 'Extras',
      pwAd: 'Ad blocker (beta)',
            cacheTitle: 'Maintenance (this tab\'s cache)', cacheUsage: 'Usage',
      cacheBtn: 'Clear cache', cacheSure: 'Are you sure? Cache will reset',
      cacheYes: 'Yes, clear', cacheNo: 'Cancel',
      cacheDone: 'cleared 🧹', cacheFail: 'failed',
      cacheNoTab: 'A Spotify tab must be open',
      pwPlayerScale: 'Player size (independent)',
      pwCover: 'Cover art (bottom bar)',
      pwCoverSize: 'Cover size',
      otherP: 'Other',
      pwThin: 'Slim scrollbars',
      langLabel: 'Language',
      resetBtn: '↺ Reset to defaults',
      instantNote: 'Changes apply instantly to open Spotify tabs — no refresh needed 🎧',
      pAMOLED: 'AMOLED', pClassic: 'Classic', pNight: 'Night', pNeon: 'Neon',
      pBlood: 'Blood', pForest: 'Forest', pAprel: 'Aprel'
    }
  };

  function langCode() {
    if (S.lang === 'tr' || S.lang === 'en') return S.lang;
    try {
      return (navigator.language || 'en').toLowerCase().indexOf('tr') === 0 ? 'tr' : 'en';
    } catch (e) { return 'en'; }
  }
  function t(key) {
    const l = langCode();
    return (I18N[l] && I18N[l][key]) || I18N.en[key] || key;
  }

  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    document.documentElement.lang = langCode();
    document.querySelectorAll('.preset .pname').forEach((el) => { el.textContent = t('p' + el.dataset.p); });
  }

  const PRESETS = [
    { k: 'AMOLED', bg: '#000000', surface: '#0d0d0d', accent: '#1db954', text: '#ffffff' },
    { k: 'Classic', bg: '#121212', surface: '#181818', accent: '#1db954', text: '#ffffff' },
    { k: 'Aprel', bg: '#04242a', surface: '#052a30', accent: '#1db954', text: '#ffffff' },
    { k: 'Night', bg: '#0a0e1a', surface: '#111a31', accent: '#4a9eff', text: '#eaf2ff' },
    { k: 'Neon', bg: '#0a0212', surface: '#1c0733', accent: '#b44dff', text: '#f6ecff' },
    { k: 'Blood', bg: '#0d0202', surface: '#230606', accent: '#ff4655', text: '#ffecec' },
    { k: 'Forest', bg: '#04120b', surface: '#0a2416', accent: '#2ecc71', text: '#eafff3' }
  ];

  const $ = (s) => document.querySelector(s);
  const rootEl = document.documentElement;

  /* v1.6.0: sync yazımları 500ms'de birleştirilir — renk kaydırırken/
     stepper basılı tutarken MAX_WRITE_OPERATIONS_PER_MINUTE kotasi
     aşılmaz (hata konsolu tertemiz) */
  let sxPend = null, sxTmr = null;
  function sxFlush() {
    if (!sxPend) return;
    const p = sxPend; sxPend = null;
    try {
      const r = chrome.storage.sync.set(p);
      if (r && r.catch) r.catch(() => {});
    } catch (e) { /* yoksay */ }
  }
  function commit(patch) {
    Object.assign(S, patch);
    if (hasChrome) {
      sxPend = Object.assign(sxPend || {}, patch);
      if (sxTmr) clearTimeout(sxTmr);
      sxTmr = setTimeout(sxFlush, 500);
    }
    refreshUI();
  }
  window.addEventListener('unload', sxFlush);

  function activePreset() {
    return PRESETS.find((p) =>
      p.bg === S.bg && p.surface === S.surface && p.accent === S.accent && p.text === S.text);
  }

  function refreshUI() {
    rootEl.style.setProperty('--acc', S.accent);

    $('#enabled').checked = !!S.enabled;
    $('#bg').value = S.bg;
    $('#surface').value = S.surface;
    $('#accent').value = S.accent;
    $('#text').value = S.text;

    $('#mscale').value = S.mscale;
    $('#scaleMode').value = S.scaleMode || 'auto';

    $('#thinScroll').checked = !!S.thinScroll;
    $('#keepAlive').checked = !!S.keepAlive;
    $('#playbackSpeed').value = S.playbackSpeed;
    $('#adBlock').checked = !!S.adBlock;
    $('#playerScale').value = S.playerScale;
    $('#playerCover').checked = !!S.playerCover;
    $('#coverSize').value = S.coverSize;
    $('#cvRow').hidden = !S.playerCover;
    $('#lang').value = S.lang;

    applyI18n();

    const act = activePreset();
    document.querySelectorAll('.preset').forEach((el) =>
      el.classList.toggle('active', act && el.dataset.p === act.k));
  }

  const wrap = $('#presets');
  PRESETS.forEach((p) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'preset';
    btn.dataset.p = p.k;
    btn.innerHTML =
      '<span class="dots">' +
      `<b style="background:${p.bg}"></b><b style="background:${p.surface}"></b><b style="background:${p.accent}"></b>` +
      '</span><span class="pname" data-p="' + p.k + '">' + t('p' + p.k) + '</span>';
    btn.addEventListener('click', () =>
      commit({ bg: p.bg, surface: p.surface, accent: p.accent, text: p.text }));
    wrap.appendChild(btn);
  });

  $('#enabled').addEventListener('change', (e) => commit({ enabled: e.target.checked }));
  $('#bg').addEventListener('input', (e) => commit({ bg: e.target.value }));
  $('#surface').addEventListener('input', (e) => commit({ surface: e.target.value }));
  $('#accent').addEventListener('input', (e) => commit({ accent: e.target.value }));
  $('#text').addEventListener('input', (e) => commit({ text: e.target.value }));

  $('#scaleMode').addEventListener('change', (e) => commit({ scaleMode: e.target.value }));

  $('#mscale').addEventListener('change', (e) => {
    const v = Math.min(Math.max(parseInt(e.target.value, 10) || 135, 100), 400);
    e.target.value = v;
    commit({ mscale: v });
  });

  $('#thinScroll').addEventListener('change', (e) => commit({ thinScroll: e.target.checked }));
  $('#keepAlive').addEventListener('change', (e) => commit({ keepAlive: e.target.checked }));
  $('#playbackSpeed').addEventListener('change', (e) => {
    const v = Math.min(Math.max(parseInt(e.target.value, 10) || 100, 50), 150);
    e.target.value = v;
    commit({ playbackSpeed: v });
  });
  $('#adBlock').addEventListener('change', (e) => commit({ adBlock: e.target.checked }));
  $('#playerCover').addEventListener('change', (e) => commit({ playerCover: e.target.checked }));
  $('#playerScale').addEventListener('change', (e) => {
    const v = Math.min(Math.max(parseInt(e.target.value, 10) || 100, 60), 300);
    e.target.value = v;
    commit({ playerScale: v });
  });
  $('#coverSize').addEventListener('change', (e) => {
    const v = Math.min(Math.max(parseInt(e.target.value, 10) || 48, 24), 120);
    e.target.value = v;
    commit({ coverSize: v });
  });
  $('#lang').addEventListener('change', (e) => commit({ lang: e.target.value }));

  $('#reset').addEventListener('click', () => commit(Object.assign({}, SX.DEFAULTS)));

  /* ---------- Bakım: Spotify önbelleği (içerik script üzerinden) ---------- */
  const askTab = (msg) => new Promise((res) => {
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        if (chrome.runtime.lastError || !r) res(null); else res(r);
      });
    } catch (e) { res(null); }
  });
  const mb = (b) => (b / 1048576).toFixed(1) + ' MB';

  async function refreshCache() {
    const u = $('#cacheUsage'), btn = $('#cacheBtn'), cf = $('#cacheConfirm');
    const r = await askTab({ type: 'sx-cache-estimate' });
    if (!r || !r.ok) { u.textContent = t('cacheNoTab'); btn.hidden = true; cf.hidden = true; return; }
    u.textContent = mb(r.usage) + ' · ' + r.caches + ' ×';
    btn.hidden = false;
  }
  $('#cacheBtn').addEventListener('click', () => {
    $('#cacheConfirm').hidden = false;
  });
  $('#cacheNo').addEventListener('click', () => {
    $('#cacheConfirm').hidden = true;
  });
  $('#cacheYes').addEventListener('click', async () => {
    const u = $('#cacheUsage'), btn = $('#cacheBtn');
    $('#cacheConfirm').hidden = true;
    u.textContent = '…';
    const r = await askTab({ type: 'sx-cache-clear' });
    if (!r || !r.ok) { u.textContent = t('cacheFail'); return; }
    u.textContent = r.cleared + ' × ' + t('cacheDone') + ' (−' + mb(r.freed) + ')';
  });

  if (hasChrome) {
    chrome.storage.sync.get(null, (stored) => {
      Object.assign(S, stored || {});
      refreshUI();
    });
    refreshCache();
    setInterval(refreshCache, 8000);
  } else {
    refreshUI();
  }
})();
